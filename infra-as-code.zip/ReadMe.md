# End to end demo OCP 4.3

1. Install AMQ Streams operator
2. `oc new-project ods-kafka`
3. `oc apply -f kafka-persistent-metrics.yaml`
4. `oc apply -f secure-reader.yml`
5. `oc apply -f secure-writer.yml`
6. Run clients

```
oc extract secret/my-cluster-cluster-ca-cert --keys=ca.crt --to=- >exec-camel/producer/certificate.crt

oc extract secret/my-cluster-cluster-ca-cert --keys=ca.crt --to=- >exec-camel/consumer/certificate.crt

rm exec-camel/consumer/trust.p12
rm exec-camel/producer/trust.p12

keytool -importcert -keystore exec-camel/producer/trust.p12 -storetype PKCS12 -alias root -storepass password -file exec-camel/producer/certificate.crt -noprompt

keytool -importcert -keystore exec-camel/consumer/trust.p12 -storetype PKCS12 -alias root -storepass password -file exec-camel/consumer/certificate.crt -noprompt

```

Get route

```
oc get route my-cluster-kafka-bootstrap -o 'jsonpath={.spec.host}'
```

Get the password from the secrets

```
oc get secret secure-topic-reader -o yaml | grep password | sed -E 's/.*password: (.*)/\1/' | base64 -d
oc get secret secure-topic-writer -o yaml | grep password | sed -E 's/.*password: (.*)/\1/' | base64 -d

```

7. Launch Consumer and producer


8. Install Kafdrop

```
oc new-app obsidiandynamics/kafdrop -e "KAFKA_BROKERCONNECT=my-cluster-kafka-bootstrap:9092" -e SERVER_SERVLET_CONTEXTPATH="/" -e JVM_OPTS="-Xms32M -Xmx512M"
oc expose dc/kafdrop --port=9000
oc expose svc kafdrop
```

9. Install monitoring

```
oc apply -f 11-prometheus.yaml
oc apply -f 12-grafana.yaml
oc expose svc grafana
```

10. Create connection Import dashboards


11. Create all source topics

```
TOPIC_NAME_LIST="egaaart egaaaql lcc0mo09 lcc0modati09 cae0master tra0taiban transaction-daily tpcccausali"
for TOPIC_NAME in $TOPIC_NAME_LIST
do
    sed -E "s/TOPIC_NAME/$TOPIC_NAME/" topic.yml | oc apply -f -
done

```

to delete all topics

```
TOPIC_NAME_LIST="egaaart egaaaql lcc0mo09 lcc0modati09 cae0master tra0taiban transaction-daily tpcccausali"
for TOPIC_NAME in $TOPIC_NAME_LIST
do
    sed -E "s/TOPIC_NAME/$TOPIC_NAME/" topic.yml | oc delete -f -
done

```

12. Create all target topics

```
TOPIC_NAME_LIST="account product-details transaction-history transaction-daily cust-account"
for TOPIC_NAME in $TOPIC_NAME_LIST
do
    sed -E "s/TOPIC_NAME/$TOPIC_NAME/" topic.yml | oc apply -f -
done

```

to delete all topics 

```
TOPIC_NAME_LIST="account product-details transaction-history transaction-daily cust-account"
for TOPIC_NAME in $TOPIC_NAME_LIST
do
    sed -E "s/TOPIC_NAME/$TOPIC_NAME/" topic.yml | oc delete -f -
done

```
